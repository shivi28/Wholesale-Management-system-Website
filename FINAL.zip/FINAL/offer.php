<html>
<body>
<center>
<a href="view_offer.php">View offer details</a></br>
<a href="edit_stock.php">Edit stock details</a>
</center>
</body>
</html>
