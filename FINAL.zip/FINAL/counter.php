<html>
	
	<body>
		<table cellspacing="2" border="2" cellpadding="2" align="center">
			<tr>
				<td><a href="search_product.php">SEARCH PRODUCT</a></td>
				<td><a href="view_customer.php">VIEW CUSTOMER</a></td>
			</tr>
		</table>
		
	</body>
</html>