<html>
<body>
<center>
<a href="view_productd.php">View Product details</a></br>
<a href="view_supplier.php">View Supplier details</a></br>
<a href="view_stock.php">View Stock details</a></br>
<a href="view_supplying.php">View Supplying details</a></br>
<a href="edit_stock.php">Edit stock details</a></br>
<a href="edit_supplying.php">Edit Supplying details</a></br>
</center>
</body>
</html>
