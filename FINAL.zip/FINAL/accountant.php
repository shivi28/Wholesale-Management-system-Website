<html>
	<body>
		<table cellspacing="2" border="2" cellpadding="2" align="center">
			<tr>
				<td><a href="view_employee.php">VIEW EMPLOYEE</a></td>
				<td><a href="view_product.php">VIEW PRODUCT</a></td>
			</tr>
			<tr>
				<td><a href="edit_product.php">EDIT PRODUCT</a></td>
				<td><a href="view_supplying.php">VIEW SUPPLYING</a></td>
			</tr>
		</table>
	</body>
</html>