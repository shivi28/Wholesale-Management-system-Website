<body>
<h1>- WELCOME ADMINISTRATOR! -<h1>
<form name="myform" action="admin_select.php" method="post"><center>
	<table border = 2>
	<tr><td align="center"> <h4> - choose table -<h4></td></tr>
	<tr><td> tables-</td>
		<td> <select name="table">
				<option value="employees"> EMPLOYEES </option>
				<option value="customers"> CUSTOMERS </option>
				<option value="products"> PRODUCTS </option>
				<option value="suppliers"> SUPPLIERS </option>
				<option value="offers"> OFFERS </option>
				<option value="discounts"> DISCOUNTS </option>
				<option value="supplying"> SUPPLYING </option>
				<option value="ordering"> ORDERING </option>
			</select><td></tr>
	<tr align="center"><input type="submit" value="OPEN"/></td></tr>
	</table></center>
</form>
</body>
